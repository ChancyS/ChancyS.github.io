var map;
var zoom;
var myChart;
var chosen=1;//地图

function initMap()
{
    map = new BMap.Map("map"); 
    map.enableScrollWheelZoom(true);     //开启鼠标滚轮缩放
    var point = new BMap.Point(115.781635,27.809476);  // 创建点坐标
    zoom=8;
    map.centerAndZoom(point, zoom);
    //添加控件：导航控件、比例尺控件、地图类型控件
    map.addControl(new BMap.NavigationControl());
    map.addControl(new BMap.ScaleControl());  
    map.addControl(new BMap.MapTypeControl());
    map.setMapStyleV2({     
        styleId: 'a2a6222d55c8be1750d608387ab9997e'
    });
    setTimeout(function(){
		getBoundary();
	}, 2);
}

function getBoundary(){       
    var bdary = new BMap.Boundary();
    bdary.get("江西省", function(rs){       //获取行政区域
        var count = rs.boundaries.length; //行政区域的点有多少个
        if (count === 0) {
            alert('未能获取当前输入行政区域');
            return ;
        }
          var pointArray = [];
        for (var i = 0; i < count; i++) {
            var ply = new BMap.Polygon(rs.boundaries[i], {strokeWeight: 5, strokeColor: "#237C77"}); //建立多边形覆盖物
            map.addOverlay(ply);  //添加覆盖物
            pointArray = pointArray.concat(ply.getPath());
        }    
        map.setViewport(pointArray);    //调整视野  
    });   
}
var option;
function initTempEcharts()
{
    //echarts
    var chartDom = document.getElementById('map');
    myChart = echarts.init(chartDom);
    var tempArray=getTempData();
    var preArray=getPreData();
    var convertData = function (tempData) {
        var res = [];
        for (var i = 0; i < stationsArray.length; i++) {
            var lat=stationsArray[i].lat;
            var lon=stationsArray[i].lon;
            var pos=[lon,lat];
            res.push({
                name: stationsArray[i].name,
                value: pos.concat(tempData[i]["value"][0])
            });
        }
        return res;
    };
    option= {
        title: {
            text: '1965-2005年鄱阳湖流域年平均温度热力图',
            subtext: 'Temperature Heatmap of Poyang Lake Basin',
            sublink: './draw.html?id=1',
            left: 'center'
        },
        tooltip : {
            trigger: 'item'
        },
        bmap: {
            center: [115.781635,27.809476],
            zoom: zoom,
            roam: true,
            mapStyle: {
                styleJson: [{
                    'featureType': 'water',
                    'elementType': 'all',
                    'stylers': {
                        'color': '#90CAF9'
                    }
                }, {
                    'featureType': 'land',
                    'elementType': 'all',
                    'stylers': {
                        'color': '#f3f3f3'
                    }
                }, {
                    'featureType': 'railway',
                    'elementType': 'all',
                    'stylers': {
                        'visibility': 'off'
                    }
                }, {
                    'featureType': 'highway',
                    'elementType': 'all',
                    'stylers': {
                        'visibility': 'off'
                    }
                }, {
                    'featureType': 'highway',
                    'elementType': 'labels',
                    'stylers': {
                        'visibility': 'off'
                    }
                }, {
                    'featureType': 'arterial',
                    'elementType': 'geometry',
                    'stylers': {
                        'color': '#fefefe'
                    }
                }, {
                    'featureType': 'arterial',
                    'elementType': 'geometry.fill',
                    'stylers': {
                        'color': '#fefefe'
                    }
                }, {
                    'featureType': 'poi',
                    'elementType': 'all',
                    'stylers': {
                        'visibility': 'off'
                    }
                }, {
                    'featureType': 'green',
                    'elementType': 'all',
                    'stylers': {
                        'visibility': 'off'
                    }
                }, {
                    'featureType': 'subway',
                    'elementType': 'all',
                    'stylers': {
                        'visibility': 'off'
                    }
                }, {
                    'featureType': 'manmade',
                    'elementType': 'all',
                    'stylers': {
                        'color': '#d1d1d1'
                    }
                }, {
                    'featureType': 'local',
                    'elementType': 'all',
                    'stylers': {
                        'color': '#d1d1d1'
                    }
                }, {
                    'featureType': 'arterial',
                    'elementType': 'labels',
                    'stylers': {
                        'visibility': 'off'
                    }
                }, {
                    'featureType': 'boundary',
                    'elementType': 'all',
                    'stylers': {
                        'color': '#8E8E8E'
                    }
                }, {
                    'featureType': 'building',
                    'elementType': 'all',
                    'stylers': {
                        'color': '#d1d1d1'
                    }
                }, {
                    'featureType': 'label',
                    'elementType': 'labels.text.fill',
                    'stylers': {
                        'color': '#999999'
                    }
                }]
            }
        },
        series : [
            {
                name: '温度',
                type: 'scatter',
                itemStyle: {
                    normal: {
                      color:"#e64a19",
                    },
                  },
                coordinateSystem: 'bmap',
                data: convertData(tempArray),
                symbolSize: function (val) {
                    return val[2] * 6;
                },
                encode: {
                    value: 2
                },
                label: {
                    formatter: '{b}',
                    position: 'right',
                    show: false
                },
                emphasis: {
                    label: {
                        show: true
                    }
                }
            },
        ]
    };

}
function initPreEcharts(){
    //echarts
    var chartDom = document.getElementById('map');
    myChart = echarts.init(chartDom);
    // var tempArray=getTempData();
    var preArray=getPreData();
    var convertData = function (tempData) {
        var res = [];
        for (var i = 0; i < stationsArray.length; i++) {
            var lat=stationsArray[i].lat;
            var lon=stationsArray[i].lon;
            var pos=[lon,lat];
            res.push({
                name: stationsArray[i].name,
                value: pos.concat(tempData[i]["value"][0])
            });
        }
        return res;
    }; 
    option= {
        title: {
            text: '1965-2005年鄱阳湖流域平均月降水热力图',
            subtext: 'Precipitation Heatmap of Poyang Lake Basin',
            sublink: './draw.html?id=1',
            left: 'center'
        },
        tooltip : {
            trigger: 'item'
        },
        bmap: {
            center: [115.781635,27.809476],
            zoom: zoom,
            roam: true,
            mapStyle: {
                styleJson: [{
                    'featureType': 'water',
                    'elementType': 'all',
                    'stylers': {
                        'color': '#90CAF9'
                    }
                }, {
                    'featureType': 'land',
                    'elementType': 'all',
                    'stylers': {
                        'color': '#f3f3f3'
                    }
                }, {
                    'featureType': 'railway',
                    'elementType': 'all',
                    'stylers': {
                        'visibility': 'off'
                    }
                }, {
                    'featureType': 'highway',
                    'elementType': 'all',
                    'stylers': {
                        'visibility': 'off'
                    }
                }, {
                    'featureType': 'highway',
                    'elementType': 'labels',
                    'stylers': {
                        'visibility': 'off'
                    }
                }, {
                    'featureType': 'arterial',
                    'elementType': 'geometry',
                    'stylers': {
                        'color': '#fefefe'
                    }
                }, {
                    'featureType': 'arterial',
                    'elementType': 'geometry.fill',
                    'stylers': {
                        'color': '#fefefe'
                    }
                }, {
                    'featureType': 'poi',
                    'elementType': 'all',
                    'stylers': {
                        'visibility': 'off'
                    }
                }, {
                    'featureType': 'green',
                    'elementType': 'all',
                    'stylers': {
                        'visibility': 'off'
                    }
                }, {
                    'featureType': 'subway',
                    'elementType': 'all',
                    'stylers': {
                        'visibility': 'off'
                    }
                }, {
                    'featureType': 'manmade',
                    'elementType': 'all',
                    'stylers': {
                        'color': '#d1d1d1'
                    }
                }, {
                    'featureType': 'local',
                    'elementType': 'all',
                    'stylers': {
                        'color': '#d1d1d1'
                    }
                }, {
                    'featureType': 'arterial',
                    'elementType': 'labels',
                    'stylers': {
                        'visibility': 'off'
                    }
                }, {
                    'featureType': 'boundary',
                    'elementType': 'all',
                    'stylers': {
                        'color': '#8E8E8E'
                    }
                }, {
                    'featureType': 'building',
                    'elementType': 'all',
                    'stylers': {
                        'color': '#d1d1d1'
                    }
                }, {
                    'featureType': 'label',
                    'elementType': 'labels.text.fill',
                    'stylers': {
                        'color': '#999999'
                    }
                }]
            }
        },
        series : [
            {
                name: '降水',
                type: 'scatter',
                coordinateSystem: 'bmap',
                data: convertData(preArray),
                symbolSize: function (val) {
                    return val[2]*3;
                },
                encode: {
                    value: 2
                },
                label: {
                    formatter: '{b}',
                    position: 'right',
                    show: false
                },
                emphasis: {
                    label: {
                        show: true
                    }
                }
            },
        ]
    };
}
initMap();
function changeToQinghuaci()
{
    if(chosen==1)
    {
        map.setMapStyleV2({     
            styleId: 'b8d6d89863f2fbf70f91ac54b7f08502'
        });
    }
    else{
        alert("当前模式不支持更换主题！");
    }
}  
function changeToChatian()
{
    if(chosen==1)
    {
        map.setMapStyleV2({     
            styleId: 'a2a6222d55c8be1750d608387ab9997e'
        });
        }
    else{
        alert("当前模式不支持更换主题！");
    }
}  

//获取所有站点坐标
function getUrl()
{
    var result;//定义查询结果
    $.ajax({
        url:'./json/stations_info.json',
        data: {},
        method:'post',
        dataType:'json',
        async:false,
        success:function(data){
            result=data;
        }
    });
        return result;//返回json数据
}
//获取气候数据
function getTempData()
{
    var result;//定义查询结果
    $.ajax({
        url:'./json/temp.json',
        data: {},
        method:'post',
        dataType:'json',
        async:false,
        success:function(data){
            result=data;
        }
    });
        return result;//返回json数据
}
//获取降水数据
function getPreData()
{
    var result;//定义查询结果
    $.ajax({
        url:'./json/pre.json',
        data: {},
        method:'post',
        dataType:'json',
        async:false,
        success:function(data){
            result=data;
        }
    });
        return result;//返回json数据
}
var stationsArray=getUrl();


//获取参数
function getQueryVariable(variable)
{
       var query = window.location.search.substring(1);
       var vars = query.split("&");
       for (var i=0;i<vars.length;i++) {
               var pair = vars[i].split("=");
               if(pair[0] == variable){return pair[1];}
       }
       return(false);
}
function setLabelStyle(content) {
    //左偏移 右偏移
    var offsetSize = new BMap.Size(0, 0);
    var labelStyle = {
        color: "#fff",
        backgroundColor: "#333333",
        border: "0",
        fontSize : "12px",
        width:"90px",
        opacity:"0.8",
        verticalAlign:"center",
        borderRadius: "2px",
        whiteSpace:"normal",
        wordWrap:"break-word",
        padding:"7px",
    };
    //用于设置样式
    var spanA="<span class='angle'><span>"
    //不同数字长度需要设置不同的样式。
    var num=parseInt(content.length/10)
    switch(num) {
        case 0:
            offsetSize = new BMap.Size(-20, -40);
            break;
        case 1:
            offsetSize = new BMap.Size(-20, -40);
            break;
        case 2:
            offsetSize = new BMap.Size(-20, -60);
            break;
        case 3:
            offsetSize = new BMap.Size(-20, -80);
            break;
        default:
            break;
    }
    var label = new BMap.Label(content+spanA, {
        offset: offsetSize
    });
    label.setStyle(labelStyle);
    return label;
}
//在地图上显示气象站
if(getQueryVariable("id")!=false)
{
    chosen=1;
    var x=getQueryVariable("id");
    var id=x-1;
    var lat=stationsArray[id]["lat"];
    var lon=stationsArray[id]["lon"];
    var name=stationsArray[id]["name"];
    var point = new BMap.Point(lon,lat);  // 创建点坐标
    map.centerAndZoom(point, 8);
    var content="<center style=\"font-size:16px\">"+name+"站</center><a id=\""+x+"\" onclick=\"javascript:window.location.href='./draw.html?id="+x+"'\" class=\"waves-effect waves-teal\" style=\"margin-top:5%;margin-left:23.5%\">查看该站点气象信息</a>";
    createMark = function(lon, lat, info_html,name) {
        var myIcon = new BMap.Icon("./pics/stations.png", new BMap.Size(40, 40)); 
        var _marker = new BMap.Marker(new BMap.Point(lon, lat),{icon:myIcon});
        _marker.addEventListener("click", function(e) {
            this.openInfoWindow(new BMap.InfoWindow(info_html,opts));
        });
        _marker.addEventListener("mouseover", function(e) {
            this.setTitle(name+"气象站(" + lon + "°E, " + lat+"°N)");
        });
        _marker.addEventListener("click", (e) => {
            this.filterMarker(e.target.point, index);
        });
        return _marker;
    };
    var marker=createMark(lon,lat,content,name);
    marker.setLabel(setLabelStyle(name+"气象站"));
    var myIcon = new BMap.Icon("./pics/stations.png", new BMap.Size(23, 25), {  
                        offset: new BMap.Size(10, 25), // 指定定位位置  
                        imageOffset: new BMap.Size(0, 0 - 10 * 25) // 设置图片偏移  
                    });  
    map.addOverlay(marker,{icon:myIcon});
}
//热力图
function showTempHeatmap()
{
    chosen=2;
    initTempEcharts();
    myChart.setOption(option,true);
}
function showPreHeatmap(){
    chosen=3;
    initPreEcharts();
    myChart.setOption(option,true);
}
var opts = {
        width : 60,     
        height: 50,     
        title : "" , 
        enableMessage:true,
        };
//添加所有气象站点，点击气象站点，显示信息框
$("#allStations").click(function(){
    if(chosen!=1)
    {
       initMap();
    }
    chosen=1;
    $("#search").attr('placeholder',"显示所有站点");
    for(var i=0;i<stationsArray.length;i++)
    { 
        var lat=stationsArray[i]["lat"];
        var lon=stationsArray[i]["lon"]; 
        var name=stationsArray[i]["name"]; 
        var content="<center style=\"font-size:16px\">"+stationsArray[i]["name"]+"站</center><a id=\""+stationsArray[i]["id"]+"\" onclick=\"javascript:window.location.href='./draw.html?id="+stationsArray[i]["id"]+"'\" class=\"waves-effect waves-teal\" style=\"margin-top:5%;margin-left:23.5%\">查看该站点气象信息</a>";
        createMark = function(lon, lat, info_html,name) {
            var myIcon = new BMap.Icon("./pics/stations.png", new BMap.Size(40, 40)); 
            var _marker = new BMap.Marker(new BMap.Point(lon, lat),{icon:myIcon});
            _marker.addEventListener("click", function(e) {
                this.openInfoWindow(new BMap.InfoWindow(info_html,opts));
            });
            _marker.addEventListener("mouseover", function(e) {
                this.setTitle(name+"气象站(" + lon + "°E, " + lat+"°N)");
            });
            _marker.addEventListener("click", (e) => {
                this.filterMarker(e.target.point, index);
            });
            return _marker;
        };
        var marker=createMark(lon,lat,content,name);
        marker.setLabel(setLabelStyle(name+"气象站"));
        map.addOverlay(marker);
    }

});

//清除标注
function clearOverlays()
{
    var allOverlay = map.getOverlays();
    for (var i = 0; i < allOverlay.length ; i++){
        map.removeOverlay(allOverlay[i]);
    }
}
function backToCenter()
{
    map.centerAndZoom(new BMap.Point(115.781635,27.809476), zoom);
}

//文本框信息变化事件
$("#searchStation").click(function()
{
    $("#search").attr('placeholder',"输入站点名");
    alert("请在右侧输入框输入站点名");
})

$("#search").attr('style',"margin-top: 1%;background-color:transparent;");
//查找气象站
$("#goForward").click(function()
{
    clearOverlays();
    var val=$("#search").val();
    for(var i=0;i<stationsArray.length;i++)
    {
        if(val==stationsArray[i]["name"])
        {
            var x=stationsArray[i]["id"];
            var lat=stationsArray[i]["lat"];
            var lon=stationsArray[i]["lon"];
            var name=stationsArray[i]["name"];
            var point = new BMap.Point(lon,lat);  // 创建点坐标
            map.centerAndZoom(point, 8);
            var content="<center style=\"font-size:16px\">"+name+"站</center><a id=\""+x+"\" onclick=\"javascript:window.location.href='./draw.html?id="+x+"'\" class=\"waves-effect waves-teal\" style=\"margin-top:5%;margin-left:23.5%\">查看该站点气象信息</a>";
            createMark = function(lon, lat, info_html,name) {
                var myIcon = new BMap.Icon("./pics/stations.png", new BMap.Size(40, 40)); 
                var _marker = new BMap.Marker(new BMap.Point(lon, lat),{icon:myIcon});
                _marker.addEventListener("click", function(e) {
                    this.openInfoWindow(new BMap.InfoWindow(info_html,opts));
                });
                _marker.addEventListener("mouseover", function(e) {
                    this.setTitle(name+"气象站(" + lon + "°E, " + lat+"°N)");
                });
                _marker.addEventListener("click", (e) => {
                    this.filterMarker(e.target.point, index);
                });
                return _marker;
            };
            var marker=createMark(lon,lat,content,name);
            marker.setLabel(setLabelStyle(name+"气象站"));
            map.addOverlay(marker);
            break;
        }
    }
    
})
function creatMark(lon,lat,name){
    var content="<center style=\"font-size:16px\">"+name+"站</center><a id=\""+x+"\" onclick=\"javascript:window.location.href='./draw.html?id="+x+"'\" class=\"waves-effect waves-teal\" style=\"margin-top:5%;margin-left:23.5%\">查看该站点气象信息</a>";
    createMark = function(lon, lat, info_html,name) {
        var myIcon = new BMap.Icon("./pics/stations.png", new BMap.Size(40, 40)); 
        var _marker = new BMap.Marker(new BMap.Point(lon, lat),{icon:myIcon});
        _marker.addEventListener("click", function(e) {
            this.openInfoWindow(new BMap.InfoWindow(info_html,opts));
        });
        _marker.addEventListener("mouseover", function(e) {
            this.setTitle(name+"气象站(" + lon + "°E, " + lat+"°N)");
        });
        _marker.addEventListener("click", (e) => {
            this.filterMarker(e.target.point, index);
        });
        return _marker;
    };
    var marker=createMark(lon,lat,content,name);
    marker.setLabel(setLabelStyle(name+"气象站"));
    map.addOverlay(marker);
}
//路径导航
$("#navTo").click(function(){
    if(chosen==1){
        map.clearOverlays();
        var start=$("#start").val();
        var destination=$("#destination").val();
       
        if(start!=""&&destination!=""){
            var startPoint;
            var desPoint;
            var count=0;
            for(var i=0;i<stationsArray.length;i++){
                if(count==2){
                    break;
                }
                if(stationsArray[i]["name"]==start){
                    var lat=stationsArray[i]["lat"];
                    var lon=stationsArray[i]["lon"];
                    startPoint = new BMap.Point(lon,lat);  // 创建点坐标
                    count+=1;
                    creatMark(lon,lat,start);
                }
                if(stationsArray[i]["name"]==destination){
                    var lat=stationsArray[i]["lat"];
                    var lon=stationsArray[i]["lon"];
                    desPoint = new BMap.Point(lon,lat);  // 创建点坐标
                    count+=1;
                    creatMark(lon,lat,destination);
                }
            }
            var driving = new BMap.DrivingRoute(map, { 
                renderOptions: { 
                    map: map, 
                    autoViewport: true 
                } 
            });
            driving.setMarkersSetCallback(function(routes){    
                    map.removeOverlay(routes[0].marker);
                    map.removeOverlay(routes[routes.length-1].marker);
                    for(var m=1;m<routes.length-1;m++){
                        var mm=routes[m].Nm;
                        map.removeOverlay(mm)
                    }
            }) 
            driving.search(startPoint,desPoint);
    }
    }else{
        alert("该模式不支持地图导航！");
    }
   
})